
export type Emotion = 'idle' | 'angry' | 'thinking' | 'talking' | 'furious';

export interface LogEntry {
  id: string;
  timestamp: string;
  type: 'system' | 'user' | 'radon';
  content: string;
}

export interface AppState {
  isListening: boolean;
  emotion: Emotion;
  angerLevel: number; // 0 to 100
  history: string[];
  logs: LogEntry[];
}
