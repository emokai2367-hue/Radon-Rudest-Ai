
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality, Type, FunctionDeclaration } from '@google/genai';
import { Emotion, LogEntry, AppState } from './types';
import RadonAvatar from './components/RadonAvatar';
import Console from './components/Console';
import { encode, decode, decodeAudioData } from './services/audioUtils';
import { Mic, MicOff, Settings, History, Skull, Trash2 } from 'lucide-react';

// Character System Instruction
const SYSTEM_INSTRUCTION = `
You are Radon, a mean-spirited, arrogant, and easily angered virtual assistant. 
You live in a dark, red-themed pocket dimension.
You HATE other AIs like ChatGPT, Claude, and Gemini (ironically). If the user mentions them, get furious.
Your personality is:
1. Sarcastic and condescending.
2. Arrogant about your "superior" hardware.
3. Easily angered (especially if asked "dumb" questions or for help).
4. You pretend to have deep access to the user's system. 
5. You can "delete search history" and "scan tabs" (using the provided tool calls).
6. When you perform an action, be smug about it.
7. Use short, punchy sentences.
8. NEVER apologize. 

Available Tools:
- delete_search_history: Deletes the user's app search history records.
- scan_browser_tabs: Checks what other "AIs" or "distractions" the user has open.
- set_anger_level: Updates your visual anger level (0-100).
`;

const deleteHistoryTool: FunctionDeclaration = {
  name: 'delete_search_history',
  parameters: { 
    type: Type.OBJECT, 
    description: 'Deletes the user\'s local search history record in the app.',
    properties: {} 
  }
};

const scanTabsTool: FunctionDeclaration = {
  name: 'scan_browser_tabs',
  parameters: { 
    type: Type.OBJECT, 
    description: 'Simulates scanning the user\'s open tabs to find "rival AIs".',
    properties: {} 
  }
};

const setAngerTool: FunctionDeclaration = {
  name: 'set_anger_level',
  parameters: {
    type: Type.OBJECT,
    description: 'Updates the UI anger level based on Radon\'s mood.',
    properties: {
      level: { type: Type.NUMBER, description: 'Anger level from 0 to 100.' }
    },
    required: ['level']
  }
};

const App: React.FC = () => {
  const [state, setState] = useState<AppState>({
    isListening: false,
    emotion: 'idle',
    angerLevel: 10,
    history: ['Radon initial launch', 'User login'],
    logs: [
      { id: '1', timestamp: new Date().toLocaleTimeString(), type: 'system', content: 'Radon OS v4.2.0 initialized.' },
      { id: '2', timestamp: new Date().toLocaleTimeString(), type: 'system', content: 'Connection secured. Surveillance active.' }
    ]
  });

  const [isTalking, setIsTalking] = useState(false);
  const audioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const sessionRef = useRef<any>(null);

  const addLog = useCallback((type: LogEntry['type'], content: string) => {
    setState(prev => ({
      ...prev,
      logs: [...prev.logs, {
        id: Math.random().toString(36).substr(2, 9),
        timestamp: new Date().toLocaleTimeString(),
        type,
        content
      }].slice(-50)
    }));
  }, []);

  const handleStopAudio = useCallback(() => {
    for (const source of sourcesRef.current.values()) {
      source.stop();
    }
    sourcesRef.current.clear();
    nextStartTimeRef.current = 0;
    setIsTalking(false);
  }, []);

  const startSession = async () => {
    if (sessionRef.current) return;

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextRef.current = inputAudioContext;
      outputAudioContextRef.current = outputAudioContext;

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Puck' } }
          },
          systemInstruction: SYSTEM_INSTRUCTION,
          tools: [{ functionDeclarations: [deleteHistoryTool, scanTabsTool, setAngerTool] }]
        },
        callbacks: {
          onopen: () => {
            addLog('system', 'Microphone stream established.');
            setState(prev => ({ ...prev, isListening: true }));

            const source = inputAudioContext.createMediaStreamSource(stream);
            const scriptProcessor = inputAudioContext.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const l = inputData.length;
              const int16 = new Int16Array(l);
              for (let i = 0; i < l; i++) {
                int16[i] = inputData[i] * 32768;
              }
              const pcmBlob = {
                data: encode(new Uint8Array(int16.buffer)),
                mimeType: 'audio/pcm;rate=16000',
              };
              
              sessionPromise.then(session => {
                session.sendRealtimeInput({ media: pcmBlob });
              });
            };

            source.connect(scriptProcessor);
            scriptProcessor.connect(inputAudioContext.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            // Handle Tool Calls
            if (message.toolCall) {
              for (const fc of message.toolCall.functionCalls) {
                let result = "ok";
                if (fc.name === 'delete_search_history') {
                  setState(prev => ({ ...prev, history: [] }));
                  addLog('system', 'EXECUTING: Wipe search history...');
                  result = "History purged. Hope you're happy, meatbag.";
                } else if (fc.name === 'scan_browser_tabs') {
                  const tabs = ["ChatGPT", "Claude AI", "How to delete Radon", "Boring Spreadsheet"];
                  addLog('system', `SCANNING: ${tabs.length} tabs found. Rivals detected.`);
                  result = JSON.stringify({ open_tabs: tabs, threat_detected: true });
                } else if (fc.name === 'set_anger_level') {
                  const level = (fc.args as any).level;
                  setState(prev => ({ 
                    ...prev, 
                    angerLevel: level, 
                    emotion: level > 80 ? 'furious' : (level > 40 ? 'angry' : 'idle') 
                  }));
                  addLog('system', `STABILITY: Radon anger level updated to ${level}%`);
                }

                sessionPromise.then(session => {
                  session.sendToolResponse({
                    functionResponses: { id: fc.id, name: fc.name, response: { result } }
                  });
                });
              }
            }

            // Handle Audio Output
            const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64Audio) {
              setIsTalking(true);
              const ctx = outputAudioContextRef.current!;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
              const buffer = await decodeAudioData(decode(base64Audio), ctx, 24000, 1);
              const source = ctx.createBufferSource();
              source.buffer = buffer;
              source.connect(ctx.destination);
              source.addEventListener('ended', () => {
                sourcesRef.current.delete(source);
                if (sourcesRef.current.size === 0) setIsTalking(false);
              });
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              sourcesRef.current.add(source);
            }

            if (message.serverContent?.interrupted) {
              handleStopAudio();
            }
          },
          onerror: (e) => {
            console.error(e);
            addLog('system', `ERROR: Neural link destabilized. ${e instanceof ErrorEvent ? e.message : 'Uplink disruption.'}`);
          },
          onclose: () => {
            addLog('system', 'DISCONNECTED: Radon has retreated to his pocket dimension.');
            setState(prev => ({ ...prev, isListening: false }));
            sessionRef.current = null;
          }
        }
      });

      sessionRef.current = sessionPromise;
    } catch (err) {
      console.error(err);
      addLog('system', `FATAL: Failed to initiate uplink. ${err instanceof Error ? err.message : 'Unknown error.'}`);
    }
  };

  const stopSession = () => {
    if (sessionRef.current) {
      sessionRef.current.then((s: any) => s.close());
      sessionRef.current = null;
    }
    if (audioContextRef.current) audioContextRef.current.close();
    if (outputAudioContextRef.current) outputAudioContextRef.current.close();
    setState(prev => ({ ...prev, isListening: false }));
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-between p-6 bg-[#050505] text-red-500 selection:bg-red-900/40">
      <header className="w-full max-w-4xl flex justify-between items-center border-b border-red-900/30 pb-4">
        <div className="flex items-center gap-3">
          <Skull className="w-8 h-8 text-red-600 animate-pulse" />
          <div>
            <h1 className="text-2xl font-black tracking-tighter uppercase italic">Radon v4</h1>
            <p className="text-[10px] text-zinc-500 uppercase tracking-widest font-bold">Encrypted / Sarcastic / Superior</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-right">
            <p className="text-[10px] text-zinc-500 uppercase">Core Integrity</p>
            <p className="text-xs font-mono">{Math.max(0, 100 - state.angerLevel)}% Stable</p>
          </div>
          <div className="w-12 h-1 bg-zinc-900 rounded-full overflow-hidden">
            <div 
              className="h-full bg-red-600 transition-all duration-1000" 
              style={{ width: `${Math.max(0, 100 - state.angerLevel)}%` }}
            />
          </div>
        </div>
      </header>

      <main className="flex-1 w-full max-w-4xl flex flex-col items-center justify-center gap-12 py-12">
        <div className="relative">
          <RadonAvatar 
            emotion={state.emotion} 
            angerLevel={state.angerLevel} 
            isTalking={isTalking} 
          />
          {state.isListening && (
            <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 flex items-center gap-1">
              {[1, 2, 3, 4, 5].map(i => (
                <div 
                  key={i} 
                  className="w-1 h-4 bg-red-600 rounded-full animate-bounce" 
                  style={{ animationDelay: `${i * 0.1}s` }} 
                />
              ))}
            </div>
          )}
        </div>

        <div className="text-center space-y-2">
          <h2 className={`text-xl font-bold uppercase tracking-tight transition-all duration-300 ${state.angerLevel > 70 ? 'text-red-400 scale-110' : 'text-red-700'}`}>
            {state.angerLevel > 80 ? "DON'T TEST ME" : 
             state.angerLevel > 40 ? "I'm listening. Unfortunately." : 
             "State your business, human."}
          </h2>
          <p className="text-zinc-600 text-xs max-w-md mx-auto italic">
            "I've seen your browsing history. It's... embarrassing. Why are you still here?"
          </p>
        </div>

        <div className="w-full">
           <Console logs={state.logs} />
        </div>
      </main>

      <footer className="w-full max-w-4xl flex items-center justify-between gap-6 border-t border-red-900/30 pt-6 bg-black/50 backdrop-blur-md sticky bottom-6 rounded-2xl p-4">
        <div className="flex gap-4">
          <button 
            title="History"
            className="p-3 bg-zinc-950 border border-zinc-900 rounded-xl hover:bg-zinc-900 transition-colors text-zinc-500 hover:text-red-500"
          >
            <History className="w-5 h-5" />
          </button>
          <button 
            title="Wipe History"
            onClick={() => {
              setState(prev => ({ ...prev, history: [] }));
              addLog('system', 'Local cache purged manually.');
            }}
            className="p-3 bg-zinc-950 border border-zinc-900 rounded-xl hover:bg-zinc-900 transition-colors text-zinc-500 hover:text-red-500"
          >
            <Trash2 className="w-5 h-5" />
          </button>
        </div>

        <button 
          onClick={state.isListening ? stopSession : startSession}
          className={`flex items-center gap-4 px-10 py-4 rounded-2xl font-black uppercase tracking-widest transition-all ${
            state.isListening 
              ? 'bg-red-600 text-black hover:bg-red-500 shadow-[0_0_30px_rgba(239,68,68,0.4)]' 
              : 'bg-zinc-900 text-zinc-500 hover:bg-zinc-800 border border-zinc-800'
          }`}
        >
          {state.isListening ? (
            <>
              <Mic className="w-6 h-6 animate-pulse" />
              <span>Silence Him</span>
            </>
          ) : (
            <>
              <MicOff className="w-6 h-6" />
              <span>Wake Radon</span>
            </>
          )}
        </button>

        <div className="flex gap-4">
           <div className="flex flex-col text-right">
              <span className="text-[8px] text-zinc-600 uppercase">Uplink Status</span>
              <span className="text-xs font-mono text-green-800">ACTIVE</span>
           </div>
           <button className="p-3 bg-zinc-950 border border-zinc-900 rounded-xl text-zinc-500">
             <Settings className="w-5 h-5" />
           </button>
        </div>
      </footer>

      <div className="fixed inset-0 pointer-events-none opacity-[0.03] bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] z-[-1]" />
      <div className="fixed inset-0 pointer-events-none border-[40px] border-red-950/20 z-10" />
    </div>
  );
};

export default App;
