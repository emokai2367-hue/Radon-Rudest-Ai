
import React from 'react';
import { Emotion } from '../types';

interface RadonAvatarProps {
  emotion: Emotion;
  angerLevel: number;
  isTalking: boolean;
}

const RadonAvatar: React.FC<RadonAvatarProps> = ({ emotion, angerLevel, isTalking }) => {
  const getGlowColor = () => {
    if (angerLevel > 80) return 'rgba(255, 0, 0, 0.9)';
    if (angerLevel > 50) return 'rgba(239, 68, 68, 0.7)';
    return 'rgba(239, 68, 68, 0.4)';
  };

  const getScale = () => {
    if (isTalking) return 1.1 + (Math.random() * 0.1);
    return 1.0;
  };

  return (
    <div className="relative flex items-center justify-center w-64 h-64">
      {/* Background Glow */}
      <div 
        className="absolute w-48 h-48 rounded-full blur-3xl transition-all duration-500"
        style={{ backgroundColor: getGlowColor() }}
      />
      
      {/* Main Body (The Crystal/Diamond shape inspired by Pocket Radon) */}
      <div 
        className={`relative w-40 h-40 transition-all duration-300 animate-float ${emotion === 'furious' ? 'glitch-text' : ''}`}
        style={{ transform: `scale(${getScale()})` }}
      >
        <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-[0_0_15px_rgba(239,68,68,0.8)]">
          {/* Outer Shell */}
          <path 
            d="M50 5 L90 50 L50 95 L10 50 Z" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="2"
            className="text-red-600"
          />
          {/* Inner Core */}
          <path 
            d="M50 15 L80 50 L50 85 L20 50 Z" 
            fill="currentColor" 
            className={`${angerLevel > 70 ? 'text-red-900' : 'text-zinc-900'} transition-colors duration-500`}
          />
          
          {/* The Eye */}
          <g transform="translate(50, 50)">
             {/* Sclera */}
             <circle r="12" fill="white" className="opacity-10" />
             {/* Pupil */}
             <circle 
               r={angerLevel > 50 ? "8" : "4"} 
               fill="currentColor" 
               className={`${angerLevel > 50 ? 'text-red-500' : 'text-red-400'} transition-all`}
             />
             {/* Eye Slit/Eyelids */}
             <path 
               d={emotion === 'angry' || emotion === 'furious' 
                 ? "M-15 -5 Q0 -12 15 -5 M-15 5 Q0 12 15 5" 
                 : "M-15 -10 Q0 -15 15 -10 M-15 10 Q0 15 15 10"} 
               fill="none" 
               stroke="black" 
               strokeWidth="4" 
             />
          </g>
        </svg>
      </div>

      {/* Anger Particles */}
      {angerLevel > 60 && Array.from({ length: 5 }).map((_, i) => (
        <div 
          key={i}
          className="absolute w-1 h-1 bg-red-500 rounded-full animate-ping"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            animationDelay: `${Math.random() * 2}s`
          }}
        />
      ))}
    </div>
  );
};

export default RadonAvatar;
