
import React, { useEffect, useRef } from 'react';
import { LogEntry } from '../types';

interface ConsoleProps {
  logs: LogEntry[];
}

const Console: React.FC<ConsoleProps> = ({ logs }) => {
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  return (
    <div className="flex flex-col h-48 bg-zinc-950 border border-red-900/30 rounded-lg p-4 font-mono text-xs overflow-y-auto shadow-inner shadow-black">
      <div className="flex items-center gap-2 mb-2 text-red-500/50 border-b border-red-900/20 pb-1">
        <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
        SYSTEM_TERMINAL [SECURE_SHELL]
      </div>
      <div className="space-y-1">
        {logs.map((log) => (
          <div key={log.id} className="flex gap-2">
            <span className="text-zinc-600">[{log.timestamp}]</span>
            <span className={
              log.type === 'radon' ? 'text-red-400' : 
              log.type === 'user' ? 'text-zinc-400' : 
              'text-blue-400 font-bold'
            }>
              {log.type.toUpperCase()}:
            </span>
            <span className="text-zinc-300">{log.content}</span>
          </div>
        ))}
        <div ref={endRef} />
      </div>
    </div>
  );
};

export default Console;
